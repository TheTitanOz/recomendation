import React, { Component } from 'react'


class Preference extends Component {

    constructor() {
        super()
        this.state = {
        }
    }

    render() {
        return (
            <div>
                
                </div>
        )
    }
}

export default Preference